==========================
Installation of NormalMAPP
==========================

Software Summary
´´´´´´´´´´´´´´´´
NormalMAPP is software for reconstructing height maps and normal maps from single image.
You can create your heightmap to calculate normal map or use your own height map instead.
Outputs of computations can be saved in png format.
NormalMAPP uses one of the newest algorithms for surface reconstrucion -  Interactive normal reconstruction from 
single image (2008). 


Availability
´´´´´´´´´´´´
NormalMAPP can be downloaded 


1. Prerequisites
	Java 8
	For Linux: GraphicsMagick 1.3.20 and above

2. Installation Linux
	You can install GraphicsMagick by following command:	apt-get install graphicsmagick
	Run setup_linux.sh script, which will install NormalMAPP to your computer.
	After installing, you can start the aplication from shell by typing "NormalMAPP"
	If message "Cannot create session folder..." appeared, run program under root.

3. Installation Windows
	Windows has build-in version of GraphicsMagick in \src\lib folder, if you have any trouble with loading images, try
	placing your own installed version of GraphicsMagick in the folder (name of installation folder must be "GraphicsMagick").
	You can start NormalMAPP with NormalMAPP file in NormalMAPP folder (original .exe file is in \src\ folder).

