#!/bin/bash

[ "$(whoami)" != "root" ] && exec sudo -- "$0" "$@";

profile=$USER;
echo "Type user and confirm or press Enter for current user $USER: ";
while read line
do
  if [ $line = "" ]; then break;
  fi;

  profile="$line";
  accoundString=$(cut -d: -f1,3 /etc/passwd | egrep ':[0-9]{4}$' | cut -d: -f1);
  IFS='\n' read -r -a accounds <<< "$accoundString";
  match=0;
    for acc in "${accounds[@]}"; do
	    if [[ $acc =~ "" && $acc = "$profile" ]]; then
		match=1;
		break;
	    fi;
    done
	if [[ $match = 0 ]]; then
	    echo "No such user."; exit;
	fi
  break;
done < "${1:-/dev/stdin}"

echo "Installing NormalMAPP for user $profile.";

#preparing icon linking with the application
sudo echo "[Desktop Entry]
Type=Application
Name=NormalMAPP
Exec=/usr/bin/NormalMAPP
Icon=/usr/share/icons/normalmapp_icon.png" > /usr/share/applications/NormalMAPP.desktop;

if [ ! -d /home/$profile/NormalMAPP ]; then
  sudo mkdir -p /home/$profile/NormalMAPP;
fi

if [ ! -d /home/$profile/NormalMAPP/lib ]; then
  sudo mkdir -p /home/$profile/NormalMAPP/lib;
fi

sudo cp ./src/lib/vecmath.jar /home/$profile/NormalMAPP/lib/
sudo cp ./src/lib/jama-1.0.3.jar /home/$profile/NormalMAPP/lib/
sudo cp ./src/lib/jai-imageio-core-1.3.0.jar /home/$profile/NormalMAPP/lib/
sudo cp ./src/lib/im4java-1.2.0.jar /home/$profile/NormalMAPP/lib/

sudo cp ./src/uninstall_linux.sh /home/$profile/NormalMAPP/

sudo cp ./src/NormalMAPP.jar /home/$profile/NormalMAPP/

sudo cp ./src/normalmapp_icon.png /usr/share/icons/

#setting up starting script
sudo echo "#!/bin/bash
java -jar /home/$profile/NormalMAPP/NormalMAPP.jar" > /usr/bin/NormalMAPP

sudo chmod 755 /usr/bin/NormalMAPP

sudo chmod 755 /home/$profile/NormalMAPP/NormalMAPP.jar

echo "Installation complete. Enter 'NormalMAPP' to the command line to start the program."

