#!/bin/bash

[ "$(whoami)" != "root" ] && exec sudo -- "$0" "$@";

echo "Uninstalling NormalMAPP.";

# remove .destop file
if [ -f /usr/share/applications/NormalMAPP.desktop ]; then
    rm /usr/share/applications/NormalMAPP.desktop
fi

# remove start script
if [ -f /usr/bin/NormalMAPP ]; then
    rm /usr/bin/NormalMAPP
fi


# remove jar file
if [ -f ./NormalMAPP.jar ]; then
    rm ./NormalMAPP.jar
fi

# removing libraries
if [ -f ./lib/vecmath.jar ]; then
    rm ./lib/vecmath.jar
fi
if [ -f ./lib/jama-1.0.3.jar ]; then
    rm ./lib/jama-1.0.3.jar
fi
if [ -f ./lib/jai-imageio-core-1.3.0.jar ]; then
    rm ./lib/jai-imageio-core-1.3.0.jar
fi
if [ -f ./lib/im4java-1.2.0.jar ]; then
    rm ./lib/im4java-1.2.0.jar
fi
if [ -f /usr/share/icons/normalmapp_icon.png ]; then
    rm /usr/share/icons/normalmapp_icon.png
fi

rm -r ./lib

cd ../

rm ./NormalMAPP/uninstall_linux.sh

rm -r ./NormalMAPP

echo "NormalMAPP uninstalled."

